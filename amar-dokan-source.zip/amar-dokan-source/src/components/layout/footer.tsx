import { Link } from "@tanstack/react-router";
import { Clock, MapPin, Phone, Store } from "lucide-react";
import { SHOP, whatsappLink } from "@/lib/shop";
import { categories } from "@/lib/products";
import { formatPhone } from "@/lib/utils";
import { WhatsAppIcon } from "@/components/whatsapp-icon";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-surface">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-fg">
              <Store className="size-5" />
            </span>
            <p className="text-lg font-semibold">{SHOP.name}</p>
          </div>
          <p className="mt-3 max-w-xs text-sm text-muted">
            বিশ্বস্ত দামে পোশাক, বই ও নিত্যপ্রয়োজনীয় জিনিস। ঘরে বসে অর্ডার করুন, সারাদেশে পৌঁছে যাবে।
          </p>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-fg">ক্যাটাগরি</h2>
          <ul className="mt-3 space-y-2">
            {categories.map((cat) => (
              <li key={cat.slug}>
                <Link
                  to="/category/$slug"
                  params={{ slug: cat.slug }}
                  className="text-sm text-muted hover:text-primary"
                >
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-fg">যোগাযোগ</h2>
          <ul className="mt-3 space-y-3 text-sm text-muted">
            <li className="flex gap-2.5">
              <Phone className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href={`tel:${SHOP.phone}`} className="hover:text-primary">
                {SHOP.phoneDisplay}
              </a>
            </li>
            <li className="flex gap-2.5">
              <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>{SHOP.address}</span>
            </li>
            <li className="flex gap-2.5">
              <Clock className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>{SHOP.hours}</span>
            </li>
          </ul>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-fg">পেমেন্ট নম্বর</h2>
          <ul className="mt-3 space-y-2 text-sm text-muted">
            <li>বিকাশ: {formatPhone(SHOP.bkash)}</li>
            <li>নগদ: {formatPhone(SHOP.nagad)}</li>
          </ul>
          <a
            href={whatsappLink(`আসসালামু আলাইকুম, ${SHOP.name}-এ অর্ডার করতে চাই।`)}
            target="_blank"
            rel="noreferrer"
            className="mt-4 inline-flex h-11 items-center gap-2 rounded-md bg-whatsapp px-4 text-sm font-medium text-whatsapp-fg hover:bg-whatsapp-hover"
          >
            <WhatsAppIcon className="size-4" />
            WhatsApp-এ অর্ডার করুন
          </a>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-sm text-subtle">
        © {new Date().getFullYear()} {SHOP.name}
      </div>
    </footer>
  );
}
