import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Phone, Store, X } from "lucide-react";
import { SHOP } from "@/lib/shop";
import { categories } from "@/lib/products";
import { Button } from "@/components/ui/button";

const links = [
  { to: "/", label: "হোম" },
  { to: "/products", label: "সব পণ্য" },
  { to: "/order", label: "অর্ডার" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-surface">
      <div className="hidden border-b border-border bg-primary text-primary-fg sm:block">
        <div className="mx-auto flex h-9 max-w-6xl items-center justify-between px-4 text-sm">
          <p>{SHOP.tagline} — সারাদেশে ডেলিভারি</p>
          <a href={`tel:${SHOP.phone}`} className="inline-flex items-center gap-1.5 font-medium">
            <Phone className="size-3.5" />
            {SHOP.phoneDisplay}
          </a>
        </div>
      </div>
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link to="/" className="flex min-w-0 items-center gap-2.5 text-fg">
          <span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-fg">
            <Store className="size-5" />
          </span>
          <span className="truncate text-lg font-semibold">{SHOP.name}</span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              search={link.to === "/order" ? {} : undefined}
              className="inline-flex h-11 items-center rounded-md px-3 text-sm font-medium text-muted hover:bg-primary-soft hover:text-fg"
              activeProps={{ className: "text-primary" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild className="hidden sm:inline-flex">
            <Link to="/order" search={{}}>
              অর্ডার করুন
            </Link>
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="md:hidden"
            aria-label={open ? "মেনু বন্ধ করুন" : "মেনু খুলুন"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border bg-surface px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-1">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                className="flex h-11 items-center rounded-md px-3 text-base font-medium text-fg hover:bg-primary-soft"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <p className="mt-4 mb-2 px-3 text-xs font-medium text-subtle">
            ক্যাটাগরি
          </p>
          <div className="flex flex-col gap-1">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                to="/category/$slug"
                params={{ slug: cat.slug }}
                onClick={() => setOpen(false)}
                className="flex h-11 items-center rounded-md px-3 text-base text-fg hover:bg-primary-soft"
              >
                {cat.name}
              </Link>
            ))}
          </div>
          <Button asChild className="mt-4 w-full">
            <Link to="/order" search={{}} onClick={() => setOpen(false)}>
              অর্ডার করুন
            </Link>
          </Button>
        </div>
      ) : null}
    </header>
  );
}
