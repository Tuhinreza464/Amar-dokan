import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { SHOP } from "@/lib/shop";
import { formatPhone } from "@/lib/utils";

function CopyRow({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-border bg-bg px-3 py-2.5">
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="font-semibold tabular-nums text-fg">{formatPhone(value)}</p>
      </div>
      <button
        type="button"
        onClick={copy}
        className="inline-flex h-11 min-w-11 items-center justify-center gap-1.5 rounded-md px-3 text-sm font-medium text-primary hover:bg-primary-soft"
      >
        {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
        {copied ? "কপি হয়েছে" : "কপি"}
      </button>
    </div>
  );
}

export function PaymentSection() {
  return (
    <section className="rounded-xl border border-border bg-surface p-5">
      <h2 className="text-lg font-semibold text-fg">বিকাশ / নগদে পেমেন্ট</h2>
      <p className="mt-1 text-sm text-muted">
        অর্ডার নিশ্চিত হলে এই নম্বরে সেন্ড মানি করুন। ট্রানজেকশন আইডি WhatsApp-এ পাঠালে দ্রুত কনফার্ম হবে। ক্যাশ অন ডেলিভারিও চলবে।
      </p>
      <div className="mt-4 grid gap-2">
        <CopyRow label="বিকাশ (পার্সোনাল)" value={SHOP.bkash} />
        <CopyRow label="নগদ (পার্সোনাল)" value={SHOP.nagad} />
      </div>
    </section>
  );
}
