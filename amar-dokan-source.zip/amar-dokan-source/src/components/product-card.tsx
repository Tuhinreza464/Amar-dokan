import { Link } from "@tanstack/react-router";
import type { Product } from "@/lib/products";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="flex flex-col overflow-hidden rounded-xl border border-border bg-surface p-2 shadow-[0_1px_2px_rgba(18,38,58,0.04)]">
      <Link
        to="/product/$id"
        params={{ id: product.id }}
        className="block overflow-hidden rounded-lg bg-primary-soft"
      >
        <img
          src={product.image}
          alt={product.name}
          width={640}
          height={800}
          className="aspect-photo w-full object-cover"
          loading="lazy"
        />
      </Link>
      <div className="flex flex-1 flex-col px-2.5 pb-2.5 pt-3">
        <h3 className="text-base font-semibold leading-snug text-fg">
          <Link to="/product/$id" params={{ id: product.id }} className="hover:text-primary">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 line-clamp-2 text-sm text-muted">{product.short}</p>
        <p className="mt-2 text-lg font-semibold tabular-nums text-primary">
          {formatPrice(product.price)}
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/product/$id" params={{ id: product.id }}>
              বিস্তারিত
            </Link>
          </Button>
          <Button size="sm" asChild>
            <Link to="/order" search={{ product: product.id }}>
              অর্ডার
            </Link>
          </Button>
        </div>
      </div>
    </article>
  );
}
