import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center px-4 py-16 text-center">
      <p className="text-sm font-medium text-primary">৪০৪</p>
      <h1 className="mt-2 text-2xl font-semibold text-fg">পাতাটি পাওয়া যায়নি</h1>
      <p className="mt-2 text-muted">লিংকটি ভুল হতে পারে, অথবা পণ্যটি আর নেই।</p>
      <a
        href="/"
        className="mt-6 inline-flex h-11 items-center rounded-md bg-primary px-5 text-sm font-medium text-primary-fg"
      >
        হোমে ফিরে যান
      </a>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}
