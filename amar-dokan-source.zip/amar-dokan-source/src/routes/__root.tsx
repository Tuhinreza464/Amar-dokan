import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { SHOP } from "@/lib/shop";
import { SEO, jsonLdScript, shopJsonLd } from "@/lib/seo";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: SEO.title },
      { name: "description", content: SEO.description },
      { name: "keywords", content: SEO.keywords },
      { name: "author", content: SHOP.name },
      { name: "robots", content: "index, follow" },
      { name: "googlebot", content: "index, follow" },
      { name: "application-name", content: SHOP.name },
      { name: "apple-mobile-web-app-title", content: SHOP.name },
      { name: "theme-color", content: "#1d4f91" },
      { name: "geo.region", content: "BD-10" },
      { name: "geo.placename", content: "Chattogram" },
      { name: "language", content: "bn" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
    scripts: [jsonLdScript(shopJsonLd())],
  }),
  component: () => (
    <html lang="bn" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="min-h-dvh bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <div className="flex min-h-dvh flex-col">
            <Header />
            <Outlet />
            <Footer />
          </div>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
