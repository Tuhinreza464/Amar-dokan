import { createFileRoute, Link } from "@tanstack/react-router";
import { categories, products } from "@/lib/products";
import { ProductCard } from "@/components/product-card";
import { jsonLdScript, pageTitle } from "@/lib/seo";
import { SHOP } from "@/lib/shop";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: pageTitle("সব পণ্য") },
      {
        name: "description",
        content:
          "আমার দোকানের সব পণ্য — পাঞ্জাবি, শার্ট, শাড়ি, কুর্তি, বই, চাল-ডাল ও বাজারের জিনিস। চট্টগ্রাম থেকে সারাদেশে ডেলিভারি।",
      },
    ],
    scripts: [
      jsonLdScript({
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        name: "সব পণ্য",
        isPartOf: SHOP.name,
      }),
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-8">
      <p className="text-sm text-muted">
        <Link to="/" className="hover:text-primary">
          হোম
        </Link>
        <span className="mx-1.5">/</span>
        সব পণ্য
      </p>
      <h1 className="mt-2 text-2xl font-semibold text-fg">সব পণ্য</h1>
      <p className="mt-1 text-sm text-muted">ক্যাটাগরি বেছে নিয়ে সহজে খুঁজুন।</p>

      <div className="mt-5 flex flex-wrap gap-2">
        <span className="inline-flex h-10 items-center rounded-full bg-primary px-4 text-sm font-medium text-primary-fg">
          সবগুলো
        </span>
        {categories.map((cat) => (
          <Link
            key={cat.slug}
            to="/category/$slug"
            params={{ slug: cat.slug }}
            className="inline-flex h-10 items-center rounded-full border border-border bg-surface px-4 text-sm font-medium text-fg hover:bg-primary-soft"
          >
            {cat.name}
          </Link>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </main>
  );
}
