import { createFileRoute, Link } from "@tanstack/react-router";
import { Truck, ShieldCheck, Wallet } from "lucide-react";
import { categories, featuredProducts } from "@/lib/products";
import { SHOP, whatsappLink } from "@/lib/shop";
import { SEO } from "@/lib/seo";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { WhatsAppIcon } from "@/components/whatsapp-icon";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: SEO.title },
      { name: "description", content: SEO.description },
    ],
  }),
  component: Home,
});

const trust = [
  {
    icon: Wallet,
    title: "ক্যাশ অন ডেলিভারি",
    text: "পণ্য হাতে পেয়ে টাকা দিন, অথবা বিকাশ/নগদে আগে পাঠান।",
  },
  {
    icon: Truck,
    title: "সারাদেশে ডেলিভারি",
    text: SHOP.delivery,
  },
  {
    icon: ShieldCheck,
    title: "বিশ্বস্ত মান",
    text: "দেখে বেছে নেওয়া পণ্য, খোলাখুলি দাম।",
  },
];

function Home() {
  const featured = featuredProducts();

  return (
    <main>
      <section className="border-b border-border bg-surface">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 lg:grid-cols-2 lg:py-16">
          <div>
            <p className="text-sm font-medium text-primary">{SHOP.name}</p>
            <h1 className="mt-2 text-3xl font-semibold text-fg sm:text-4xl">
              ঘরে বসে কেনাকাটা, বিশ্বস্ত দামে
            </h1>
            <p className="mt-3 max-w-md text-muted">
              ছেলেদের ও মেয়েদের পোশাক, বই এবং নিত্যপ্রয়োজনীয় জিনিস এক জায়গায়। অর্ডার ফর্ম পূরণ করুন, অথবা WhatsApp-এ কথা বলুন।
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/products">পণ্য দেখুন</Link>
              </Button>
              <Button variant="whatsapp" asChild>
                <a
                  href={whatsappLink(`আসসালামু আলাইকুম, ${SHOP.name}-এ অর্ডার করতে চাই।`)}
                  target="_blank"
                  rel="noreferrer"
                >
                  <WhatsAppIcon className="size-4" />
                  WhatsApp-এ অর্ডার করুন
                </a>
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                to="/category/$slug"
                params={{ slug: cat.slug }}
                className="group overflow-hidden rounded-xl border border-border"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  width={480}
                  height={360}
                  className="aspect-hero w-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
                />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold text-fg">ক্যাটাগরি</h2>
          <p className="mt-1 text-sm text-muted">যে বিভাগ থেকে কিনতে চান, সেখানে ঢুকুন।</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((cat) => (
            <Link
              key={cat.slug}
              to="/category/$slug"
              params={{ slug: cat.slug }}
              className="overflow-hidden rounded-xl border border-border bg-surface p-2 hover:border-primary/40"
            >
              <img
                src={cat.image}
                alt=""
                width={480}
                height={320}
                className="aspect-wide w-full rounded-lg object-cover"
              />
              <div className="px-2 py-3">
                <h3 className="font-semibold text-fg">{cat.name}</h3>
                <p className="mt-0.5 text-sm text-muted">{cat.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-10">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold text-fg">নির্বাচিত পণ্য</h2>
            <p className="mt-1 text-sm text-muted">এখন যা বেশি অর্ডার হচ্ছে।</p>
          </div>
          <Button variant="outline" asChild>
            <Link to="/products">সবগুলো দেখুন</Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-surface">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 sm:grid-cols-3">
          {trust.map((item) => (
            <div key={item.title} className="flex gap-3">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-md bg-primary-soft text-primary">
                <item.icon className="size-5" />
              </span>
              <div>
                <h3 className="font-semibold text-fg">{item.title}</h3>
                <p className="mt-1 text-sm text-muted">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
