import { createFileRoute, Link } from "@tanstack/react-router";
import { getCategory, getProduct } from "@/lib/products";
import { buildProductInquiry, whatsappLink } from "@/lib/shop";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { WhatsAppIcon } from "@/components/whatsapp-icon";
import { jsonLdScript, pageTitle, productDescription, productJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/product/$id")({
  head: ({ params }) => {
    const product = getProduct(params.id);
    if (!product) {
      return { meta: [{ title: pageTitle("পণ্য পাওয়া যায়নি") }] };
    }
    return {
      meta: [
        { title: pageTitle(product.name) },
        { name: "description", content: productDescription(product) },
      ],
      scripts: [jsonLdScript(productJsonLd(product))],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const product = getProduct(id);

  if (!product) {
    return (
      <main className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="text-2xl font-semibold">পণ্য পাওয়া যায়নি</h1>
        <Link to="/products" className="mt-4 inline-block text-primary">
          সব পণ্য দেখুন
        </Link>
      </main>
    );
  }

  const category = getCategory(product.category);

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-8">
      <p className="text-sm text-muted">
        <Link to="/" className="hover:text-primary">
          হোম
        </Link>
        {category ? (
          <>
            <span className="mx-1.5">/</span>
            <Link
              to="/category/$slug"
              params={{ slug: category.slug }}
              className="hover:text-primary"
            >
              {category.name}
            </Link>
          </>
        ) : null}
        <span className="mx-1.5">/</span>
        {product.name}
      </p>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-xl border border-border bg-primary-soft p-2">
          <img
            src={product.image}
            alt={product.name}
            width={800}
            height={1000}
            className="aspect-photo w-full rounded-lg object-cover"
          />
        </div>
        <div>
          {category ? <Badge>{category.name}</Badge> : null}
          <h1 className="mt-3 text-3xl font-semibold text-fg">{product.name}</h1>
          <p className="mt-3 text-2xl font-semibold tabular-nums text-primary">
            {formatPrice(product.price)}
          </p>
          <p className="mt-4 text-muted">{product.description}</p>
          <ul className="mt-5 space-y-2 text-sm text-fg">
            <li>স্টকে আছে</li>
            <li>ক্যাশ অন ডেলিভারি চলবে</li>
            <li>ঢাকায় ১–২ দিনে ডেলিভারি</li>
          </ul>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button asChild className="sm:flex-1">
              <Link to="/order" search={{ product: product.id }}>
                অর্ডার ফর্ম পূরণ করুন
              </Link>
            </Button>
            <Button variant="whatsapp" asChild className="sm:flex-1">
              <a
                href={whatsappLink(buildProductInquiry(product.name, product.price))}
                target="_blank"
                rel="noreferrer"
              >
                <WhatsAppIcon className="size-4" />
                WhatsApp-এ অর্ডার করুন
              </a>
            </Button>
          </div>
        </div>
      </div>
    </main>
  );
}
