import { useMemo, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, Minus, Plus } from "lucide-react";
import { getProduct, products } from "@/lib/products";
import { buildOrderMessage, whatsappLink } from "@/lib/shop";
import { formatPrice } from "@/lib/utils";
import { pageTitle } from "@/lib/seo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PaymentSection } from "@/components/payment-section";
import { WhatsAppIcon } from "@/components/whatsapp-icon";

type OrderSearch = {
  product?: string;
};

type Submitted = {
  name: string;
  mobile: string;
  address: string;
  productName: string;
  quantity: number;
  total: number;
  message: string;
};

export const Route = createFileRoute("/order")({
  validateSearch: (search: Record<string, unknown>): OrderSearch => ({
    product: typeof search.product === "string" ? search.product : undefined,
  }),
  head: () => ({
    meta: [
      { title: pageTitle("অর্ডার করুন") },
      {
        name: "description",
        content:
          "আমার দোকানে অর্ডার করুন — নাম, মোবাইল ও ঠিকানা দিন। WhatsApp, বিকাশ, নগদ অথবা ক্যাশ অন ডেলিভারি। চট্টগ্রাম থেকে সারাদেশে পৌঁছে যাবে।",
      },
      { name: "robots", content: "index, follow" },
    ],
  }),
  component: OrderPage,
});

function OrderPage() {
  const { product: preselected } = Route.useSearch();
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddress] = useState("");
  const [productId, setProductId] = useState(preselected ?? products[0]?.id ?? "");
  const [quantity, setQuantity] = useState(1);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState<Submitted | null>(null);

  const product = getProduct(productId);
  const total = useMemo(
    () => (product ? product.price * quantity : 0),
    [product, quantity],
  );

  function validate() {
    const next: Record<string, string> = {};
    if (name.trim().length < 2) next.name = "নাম লিখুন";
    const digits = mobile.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(digits)) next.mobile = "সঠিক মোবাইল নম্বর দিন (০১XXXXXXXXX)";
    if (address.trim().length < 8) next.address = "সম্পূর্ণ ঠিকানা লিখুন";
    if (!product) next.product = "একটি পণ্য বেছে নিন";
    if (quantity < 1) next.quantity = "পরিমাণ কমপক্ষে ১ হতে হবে";
    return next;
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length > 0 || !product) return;

    const payload = {
      name: name.trim(),
      mobile: mobile.replace(/\D/g, ""),
      address: address.trim(),
      productName: product.name,
      quantity,
      total,
    };
    setSubmitted({
      ...payload,
      message: buildOrderMessage(payload),
    });
  }

  if (submitted) {
    return (
      <main className="mx-auto w-full max-w-xl px-4 py-10">
        <div className="rounded-xl border border-border bg-surface p-6 text-center">
          <CheckCircle2 className="mx-auto size-12 text-success" />
          <h1 className="mt-3 text-2xl font-semibold text-fg">অর্ডার গ্রহণ করা হয়েছে</h1>
          <p className="mt-2 text-sm text-muted">
            আপনার তথ্য সংরক্ষণ করা হয়েছে। নিশ্চিত করতে WhatsApp-এ পাঠান, আমরা দ্রুত যোগাযোগ করব।
          </p>
          <dl className="mt-5 space-y-2 rounded-lg bg-bg px-4 py-3 text-left text-sm">
            <div className="flex justify-between gap-3">
              <dt className="text-muted">পণ্য</dt>
              <dd className="font-medium">{submitted.productName}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted">পরিমাণ</dt>
              <dd className="font-medium tabular-nums">{submitted.quantity}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-muted">মোট</dt>
              <dd className="font-semibold tabular-nums text-primary">
                {formatPrice(submitted.total)}
              </dd>
            </div>
          </dl>
          <div className="mt-5 flex flex-col gap-3">
            <Button variant="whatsapp" asChild>
              <a href={whatsappLink(submitted.message)} target="_blank" rel="noreferrer">
                <WhatsAppIcon className="size-4" />
                WhatsApp-এ পাঠান
              </a>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/">হোমে ফিরে যান</Link>
            </Button>
          </div>
        </div>
        <div className="mt-6">
          <PaymentSection />
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto w-full max-w-3xl px-4 py-8">
      <p className="text-sm text-muted">
        <Link to="/" className="hover:text-primary">
          হোম
        </Link>
        <span className="mx-1.5">/</span>
        অর্ডার
      </p>
      <h1 className="mt-2 text-2xl font-semibold text-fg">অর্ডার ফর্ম</h1>
      <p className="mt-1 text-sm text-muted">
        তথ্য পূরণ করুন। সাবমিটের পর WhatsApp-এ পাঠানোর সুযোগ থাকবে।
      </p>

      <form onSubmit={onSubmit} className="mt-6 space-y-5 rounded-xl border border-border bg-surface p-5">
        <div>
          <Label htmlFor="name">নাম</Label>
          <Input
            id="name"
            name="name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1.5"
            placeholder="আপনার পুরো নাম"
          />
          {errors.name ? <p className="mt-1 text-sm text-danger">{errors.name}</p> : null}
        </div>

        <div>
          <Label htmlFor="mobile">মোবাইল নম্বর</Label>
          <Input
            id="mobile"
            name="mobile"
            type="tel"
            inputMode="numeric"
            autoComplete="tel"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className="mt-1.5"
            placeholder="01XXXXXXXXX"
          />
          {errors.mobile ? <p className="mt-1 text-sm text-danger">{errors.mobile}</p> : null}
        </div>

        <div>
          <Label htmlFor="address">ঠিকানা</Label>
          <Textarea
            id="address"
            name="address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="mt-1.5"
            placeholder="বাড়ি/রোড, এলাকা, থানা, জেলা"
          />
          {errors.address ? <p className="mt-1 text-sm text-danger">{errors.address}</p> : null}
        </div>

        <div>
          <Label htmlFor="product">পণ্য</Label>
          <select
            id="product"
            name="product"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            className="mt-1.5 h-11 w-full rounded-md border border-border bg-surface px-3 text-base text-fg outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
          >
            {products.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name} — {formatPrice(item.price)}
              </option>
            ))}
          </select>
          {errors.product ? <p className="mt-1 text-sm text-danger">{errors.product}</p> : null}
        </div>

        <div>
          <Label htmlFor="quantity">পরিমাণ</Label>
          <div className="mt-1.5 flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              aria-label="কমান"
              onClick={() => setQuantity((n) => Math.max(1, n - 1))}
            >
              <Minus className="size-4" />
            </Button>
            <Input
              id="quantity"
              name="quantity"
              type="number"
              min={1}
              max={20}
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, Math.min(20, Number(e.target.value) || 1)))}
              className="w-20 text-center tabular-nums"
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              aria-label="বাড়ান"
              onClick={() => setQuantity((n) => Math.min(20, n + 1))}
            >
              <Plus className="size-4" />
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg bg-bg px-4 py-3">
          <span className="text-sm text-muted">মোট</span>
          <span className="text-xl font-semibold tabular-nums text-primary">
            {formatPrice(total)}
          </span>
        </div>

        <Button type="submit" className="w-full" size="lg">
          অর্ডার নিশ্চিত করুন
        </Button>
      </form>

      <div className="mt-6">
        <PaymentSection />
      </div>
    </main>
  );
}
