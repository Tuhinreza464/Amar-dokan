import { createFileRoute, Link } from "@tanstack/react-router";
import { getCategory, getProductsByCategory, type CategorySlug } from "@/lib/products";
import { ProductCard } from "@/components/product-card";
import { jsonLdScript, pageTitle } from "@/lib/seo";
import { SHOP } from "@/lib/shop";

export const Route = createFileRoute("/category/$slug")({
  head: ({ params }) => {
    const category = getCategory(params.slug);
    if (!category) {
      return { meta: [{ title: pageTitle("ক্যাটাগরি পাওয়া যায়নি") }] };
    }
    const description = `${category.name} — ${category.description}। চট্টগ্রামের ${SHOP.name} থেকে অর্ডার করুন।`;
    return {
      meta: [
        { title: pageTitle(category.name) },
        { name: "description", content: description },
      ],
      scripts: [
        jsonLdScript({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: category.name,
          description,
        }),
      ],
    };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const category = getCategory(slug);

  if (!category) {
    return (
      <main className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="text-2xl font-semibold">ক্যাটাগরি পাওয়া যায়নি</h1>
        <Link to="/products" className="mt-4 inline-block text-primary">
          সব পণ্য দেখুন
        </Link>
      </main>
    );
  }

  const items = getProductsByCategory(category.slug as CategorySlug);

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-8">
      <p className="text-sm text-muted">
        <Link to="/" className="hover:text-primary">
          হোম
        </Link>
        <span className="mx-1.5">/</span>
        {category.name}
      </p>
      <h1 className="mt-2 text-2xl font-semibold text-fg">{category.name}</h1>
      <p className="mt-1 text-sm text-muted">{category.description}</p>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {items.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </main>
  );
}
