import { categories, products, type Product } from "@/lib/products";
import { SHOP } from "@/lib/shop";
import { formatPrice } from "@/lib/utils";

export const SEO = {
  siteName: SHOP.name,
  title: `${SHOP.name} | চট্টগ্রাম থেকে অনলাইন কেনাকাটা`,
  description:
    "চট্টগ্রামের আমার দোকান — ছেলেদের ও মেয়েদের পোশাক, বই এবং নিত্যপ্রয়োজনীয় জিনিস। WhatsApp-এ অর্ডার করুন, ক্যাশ অন ডেলিভারি ও সারাদেশে পৌঁছে যাবে।",
  keywords:
    "আমার দোকান, অনলাইন শপ, চট্টগ্রাম, পাঞ্জাবি, শাড়ি, কুর্তি, বই, নিত্যপ্রয়োজনীয়, WhatsApp অর্ডার, ক্যাশ অন ডেলিভারি, Amar Dokan, Chittagong online shop",
} as const;

export function pageTitle(page: string) {
  return `${page} | ${SEO.siteName}`;
}

export function jsonLdScript(data: object) {
  return {
    type: "application/ld+json" as const,
    children: JSON.stringify(data),
  };
}

export function shopJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Store",
    name: SHOP.name,
    alternateName: "Amar Dokan",
    description: SEO.description,
    telephone: `+${SHOP.whatsapp}`,
    address: {
      "@type": "PostalAddress",
      addressLocality: SHOP.address,
      addressRegion: "Chattogram",
      addressCountry: "BD",
    },
    areaServed: {
      "@type": "Country",
      name: "Bangladesh",
    },
    currenciesAccepted: "BDT",
    paymentAccepted: "Cash, bKash, Nagad",
    openingHours: "Mo-Su 10:00-21:00",
    priceRange: "৳৳",
  };
}

export function productJsonLd(product: Product) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    image: product.image,
    brand: { "@type": "Brand", name: SHOP.name },
    offers: {
      "@type": "Offer",
      priceCurrency: "BDT",
      price: String(product.price),
      availability: "https://schema.org/InStock",
      itemCondition: "https://schema.org/NewCondition",
    },
  };
}

export function productDescription(product: Product) {
  return `${product.name} — ${product.short}। দাম ${formatPrice(product.price)}। চট্টগ্রামের ${SHOP.name} থেকে WhatsApp-এ অর্ডার করুন।`;
}

export function sitemapPaths() {
  return [
    "/",
    "/products",
    "/order",
    ...categories.map((c) => `/category/${c.slug}`),
    ...products.map((p) => `/product/${p.id}`),
  ];
}

export function requestOrigin(request: Request) {
  const url = new URL(request.url);
  const host =
    request.headers.get("x-forwarded-host")?.split(",")[0]?.trim() ||
    request.headers.get("host") ||
    url.host;
  const proto =
    request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() ||
    url.protocol.replace(":", "") ||
    "https";
  return `${proto}://${host}`;
}
