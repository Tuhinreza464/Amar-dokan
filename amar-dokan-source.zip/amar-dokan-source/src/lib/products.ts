export type CategorySlug = "men" | "women" | "books" | "daily";

export type Product = {
  id: string;
  name: string;
  price: number;
  short: string;
  description: string;
  image: string;
  category: CategorySlug;
};

export type Category = {
  slug: CategorySlug;
  name: string;
  description: string;
  image: string;
};

export const categories: Category[] = [
  {
    slug: "men",
    name: "ছেলেদের পোশাক",
    description: "পাঞ্জাবি, শার্ট, টি-শার্ট ও জিন্স",
    image: "/products/panjabi.jpg",
  },
  {
    slug: "women",
    name: "মেয়েদের পোশাক",
    description: "শাড়ি, কুর্তি ও হিজাব",
    image: "/products/saree.jpg",
  },
  {
    slug: "books",
    name: "বই",
    description: "উপন্যাস, গাইড ও খাতা",
    image: "/products/novel.jpg",
  },
  {
    slug: "daily",
    name: "নিত্যপ্রয়োজনীয় জিনিস",
    description: "চাল, ডাল, তেল ও বাজার",
    image: "/products/rice.jpg",
  },
];

export const products: Product[] = [
  {
    id: "panjabi",
    name: "ক্রিম কটন পাঞ্জাবি",
    price: 1850,
    short: "নরম কটন, আরামদায়ক ফিট",
    description:
      "ঈদ ও দৈনন্দিন পরার জন্য হালকা ক্রিম রঙের কটন পাঞ্জাবি। কাপড় নরম, সেলাই মজবুত। সাইজ এম, এল ও এক্সএল পাওয়া যায়।",
    image: "/products/panjabi.jpg",
    category: "men",
  },
  {
    id: "shirt",
    name: "নেভি ফরমাল শার্ট",
    price: 1250,
    short: "অফিস ও অনুষ্ঠানের জন্য",
    description:
      "গাঢ় নীল ফরমাল শার্ট। আয়রন-ইজি কাপড়, বোতাম মজবুত। অফিস, সাক্ষাৎকার ও অনুষ্ঠানে পরার উপযোগী।",
    image: "/products/shirt.jpg",
    category: "men",
  },
  {
    id: "tshirt",
    name: "নেভি প্রিন্টেড টি-শার্ট",
    price: 690,
    short: "কটন জার্সি, রোজকার পোশাক",
    description:
      "১০০% কটন জার্সির প্রিন্টেড টি-শার্ট। কাপড় নরম, রঙ উঠে না। ক্যাজুয়াল পরার জন্য আরামদায়ক।",
    image: "/products/tshirt.jpg",
    category: "men",
  },
  {
    id: "jeans",
    name: "স্লিম ফিট জিন্স",
    price: 1890,
    short: "স্ট্রেচ ডেনিম, টেকসই",
    description:
      "গাঢ় নীল স্লিম ফিট জিন্স। হালকা স্ট্রেচ থাকায় আরামদায়ক। ধোয়ার পরেও ফিট ঠিক থাকে।",
    image: "/products/jeans.jpg",
    category: "men",
  },
  {
    id: "saree",
    name: "পিঙ্ক সিল্ক শাড়ি",
    price: 3450,
    short: "উজ্জ্বল সিল্ক, অনুষ্ঠানের জন্য",
    description:
      "উজ্জ্বল গোলাপি সিল্ক শাড়ি। হালকা ও আরামদায়ক, ব্লাউজ পিসসহ। বিয়েবাড়ি ও অনুষ্ঠানে পরার জন্য উপযোগী।",
    image: "/products/saree.jpg",
    category: "women",
  },
  {
    id: "kurti",
    name: "লাল এমব্রয়ডারি কুর্তি",
    price: 1590,
    short: "সূচিকর্ম করা কটন কুর্তি",
    description:
      "লাল কটন কুর্তি, সামনে সূচিকর্ম। আরামদায়ক কাপড়, রোজকার ও হালকা অনুষ্ঠানে পরার উপযোগী।",
    image: "/products/kurti.jpg",
    category: "women",
  },
  {
    id: "hijab",
    name: "নেভি প্রিমিয়াম হিজাব",
    price: 480,
    short: "নরম কাপড়, সহজে পরা যায়",
    description:
      "গাঢ় নীল প্রিমিয়াম হিজাব। কাপড় পাতলা নয়, স্বচ্ছও নয়। দৈনন্দিন পরার জন্য আরামদায়ক।",
    image: "/products/hijab.jpg",
    category: "women",
  },
  {
    id: "novel",
    name: "বাংলা উপন্যাস",
    price: 380,
    short: "হার্ডকভার, পরিষ্কার ছাপা",
    description:
      "জনপ্রিয় বাংলা উপন্যাস। পরিষ্কার ছাপা, মজবুত বাঁধাই। উপহার ও নিজের পড়ার জন্য উপযোগী।",
    image: "/products/novel.jpg",
    category: "books",
  },
  {
    id: "english-book",
    name: "ইংরেজি গ্রামার গাইড",
    price: 420,
    short: "স্কুল-কলেজের সহায়ক বই",
    description:
      "সহজ ভাষায় ইংরেজি গ্রামার গাইড। উদাহরণ ও অনুশীলনীসহ। শিক্ষার্থীদের জন্য উপযোগী।",
    image: "/products/english-book.jpg",
    category: "books",
  },
  {
    id: "kids-book",
    name: "ছোটদের রূপকথার বই",
    price: 260,
    short: "রঙিন ছবিসহ গল্পের বই",
    description:
      "ছোটদের জন্য রূপকথা ও নীতিকথা। বড় অক্ষর, রঙিন ছবি। শিশুদের পড়ার অভ্যাস গড়তে সাহায্য করে।",
    image: "/products/kids-book.jpg",
    category: "books",
  },
  {
    id: "notebook",
    name: "স্পাইরাল নোটবুক",
    price: 150,
    short: "মোটা কাগজ, ২০০ পাতা",
    description:
      "স্পাইরাল বাঁধাইয়ের নোটবুক। মোটা কাগজ, লেখা সহজ। স্কুল, কলেজ ও অফিসের জন্য।",
    image: "/products/notebook.jpg",
    category: "books",
  },
  {
    id: "rice",
    name: "মিনিকেট চাল (৫ কেজি)",
    price: 520,
    short: "সুগন্ধি, পরিষ্কার চাল",
    description:
      "৫ কেজির মিনিকেট চাল। ভাত ঝরঝরে হয়, ধুলা-বালির মিশ্রণ নেই। পরিবারের রোজকার রান্নার জন্য।",
    image: "/products/rice.jpg",
    category: "daily",
  },
  {
    id: "lentils",
    name: "মসুর ডাল (১ কেজি)",
    price: 160,
    short: "পরিষ্কার, দ্রুত সিদ্ধ",
    description:
      "১ কেজি মসুর ডাল। পাথর-কুচি বাছাই করা, দ্রুত সিদ্ধ হয়। দৈনন্দিন রান্নার জন্য।",
    image: "/products/lentils.jpg",
    category: "daily",
  },
  {
    id: "oil",
    name: "সয়াবিন তেল (২ লিটার)",
    price: 390,
    short: "রান্নার তেল, সিল করা বোতল",
    description:
      "২ লিটার সয়াবিন তেল। সিল করা বোতল, রান্নার জন্য উপযোগী। তাজা সরবরাহ।",
    image: "/products/oil.jpg",
    category: "daily",
  },
  {
    id: "tea",
    name: "প্রিমিয়াম চা পাতা (২০০ গ্রাম)",
    price: 220,
    short: "ঘন রঙ, সুগন্ধি চা",
    description:
      "২০০ গ্রাম প্রিমিয়াম চা পাতা। ঘন রঙ ও সুগন্ধ। সকাল-বিকেলের চায়ের জন্য।",
    image: "/products/tea.jpg",
    category: "daily",
  },
  {
    id: "soap",
    name: "গ্লিসারিন সাবান",
    price: 85,
    short: "ত্বকের জন্য মৃদু সাবান",
    description:
      "গ্লিসারিন সমৃদ্ধ সাবান। ত্বক শুষ্ক করে না। পরিবারের সবার জন্য ব্যবহারযোগ্য।",
    image: "/products/soap.jpg",
    category: "daily",
  },
  {
    id: "toothpaste",
    name: "হার্বাল টুথপেস্ট",
    price: 95,
    short: "তাজা নিঃশ্বাস, কোমল ফর্মুলা",
    description:
      "হার্বাল টুথপেস্ট। দাঁত পরিষ্কার রাখে, নিঃশ্বাস রাখে তাজা। সিল করা টিউব।",
    image: "/products/toothpaste.jpg",
    category: "daily",
  },
];

export function getCategory(slug: string) {
  return categories.find((c) => c.slug === slug);
}

export function getProduct(id: string) {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(slug: CategorySlug) {
  return products.filter((p) => p.category === slug);
}

export function featuredProducts() {
  return [
    getProduct("panjabi")!,
    getProduct("saree")!,
    getProduct("kurti")!,
    getProduct("shirt")!,
    getProduct("rice")!,
    getProduct("novel")!,
    getProduct("jeans")!,
    getProduct("tea")!,
  ];
}
