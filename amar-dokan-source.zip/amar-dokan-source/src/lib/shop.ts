export const SHOP = {
  name: "আমার দোকান",
  tagline: "ঘরে বসে কেনাকাটা",
  phone: "01515219717",
  phoneDisplay: "01515-219717",
  whatsapp: "8801515219717",
  address: "চট্টগ্রাম",
  hours: "সকাল ১০টা – রাত ৯টা",
  bkash: "01515219717",
  nagad: "01515219717",
  delivery: "ঢাকায় ১–২ দিন, ঢাকার বাইরে ৩–৫ দিন",
} as const;

export function whatsappLink(text: string) {
  return `https://wa.me/${SHOP.whatsapp}?text=${encodeURIComponent(text)}`;
}

export function buildOrderMessage(order: {
  name: string;
  mobile: string;
  address: string;
  productName: string;
  quantity: number;
  total: number;
}) {
  return [
    `নতুন অর্ডার — ${SHOP.name}`,
    "",
    `নাম: ${order.name}`,
    `মোবাইল: ${order.mobile}`,
    `ঠিকানা: ${order.address}`,
    `পণ্য: ${order.productName}`,
    `পরিমাণ: ${order.quantity}`,
    `মোট: ৳${order.total.toLocaleString("bn-BD")}`,
    "",
    "পেমেন্ট: বিকাশ/নগদ অথবা ক্যাশ অন ডেলিভারি",
  ].join("\n");
}

export function buildProductInquiry(productName: string, price: number) {
  return `আসসালামু আলাইকুম, আমি এই পণ্যটি নিতে চাই: ${productName} (৳${price.toLocaleString("bn-BD")})`;
}
